<?php
// Heading
$_['heading_title']    = 'Mobile App';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified mobile app module!';
$_['text_edit']        = 'Edit Mobile App Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify test module!';
