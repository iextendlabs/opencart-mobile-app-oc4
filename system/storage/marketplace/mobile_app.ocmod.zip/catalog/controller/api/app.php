<?php
namespace Opencart\Catalog\Controller\Extension\MobileApp\Api;
/**
 * Class Coupon
 *
 * @package Opencart\Catalog\Controller\Extension\MobileApp\Api
 */
class App extends \Opencart\System\Engine\Controller {
    public function login(): void {
        $this->load->language('extension/mobile_app/api/app');

        $json = [];

        $request_body = file_get_contents('php://input');
        $data = json_decode($request_body, true);

        $email = $data['email'] ?? '';
        $password = $data['password'] ?? '';

        // Validate the credentials
        if (!$this->customer->login($email, $password)) {
            $json['error'] = $this->language->get('error_login');
        } else {
            $this->load->model('account/customer');
            $customer_info = $this->model_account_customer->getCustomerByEmail($email);

            if ($customer_info) {
                $token = bin2hex(random_bytes(32));

                $json['token'] = $token;
                $json['user'] = [
                    'id' => $customer_info['customer_id'],
                    'firstname' => $customer_info['firstname'],
                    'lastname' => $customer_info['lastname'],
                    'email' => $customer_info['email']
                ];
                $json['message'] = $this->language->get('text_success');
            } else {
                $json['error'] = $this->language->get('error_login');
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
}
